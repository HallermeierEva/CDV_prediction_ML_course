"""
Visualization Module
Author: Eva Hallermeier

This module creates publication-quality visualizations for model
comparison and analysis.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
import json

from . import config


class ModelVisualizer:
    """
    Creates visualizations for model comparison and analysis.
    """
    
    def __init__(self):
        """Initialize the visualizer with default settings."""
        plt.style.use('seaborn-v0_8-whitegrid')
        self.setup_plotting_style()
        
    def setup_plotting_style(self):
        """Set up consistent plotting style."""
        plt.rcParams['figure.dpi'] = 100
        plt.rcParams['savefig.dpi'] = config.FIGURE_DPI
        plt.rcParams['font.size'] = 11
        plt.rcParams['axes.labelsize'] = config.FONT_SIZES['label']
        plt.rcParams['axes.titlesize'] = config.FONT_SIZES['title']
        plt.rcParams['legend.fontsize'] = config.FONT_SIZES['legend']
        plt.rcParams['xtick.labelsize'] = config.FONT_SIZES['tick']
        plt.rcParams['ytick.labelsize'] = config.FONT_SIZES['tick']
    
    def plot_roc_comparison(self, lr_results, xgb_results, save_path=None):
        """
        Plot ROC curves for both models.
        
        Parameters:
        -----------
        lr_results : dict
            Logistic regression results
        xgb_results : dict
            XGBoost results
        save_path : str or Path, optional
            Path to save the figure
        """
        fig, ax = plt.subplots(figsize=config.FIGURE_SIZE_STANDARD)
        
        # Plot Logistic Regression
        fpr_lr = lr_results['roc_curve']['fpr']
        tpr_lr = lr_results['roc_curve']['tpr']
        auc_lr = lr_results['roc_auc']
        
        ax.plot(fpr_lr, tpr_lr, color=config.COLORS['lr'], lw=2,
                label=f'Logistic Regression (AUC = {auc_lr:.4f})')
        
        # Plot XGBoost
        fpr_xgb = xgb_results['roc_curve']['fpr']
        tpr_xgb = xgb_results['roc_curve']['tpr']
        auc_xgb = xgb_results['roc_auc']
        
        ax.plot(fpr_xgb, tpr_xgb, color=config.COLORS['xgb'], lw=2,
                label=f'XGBoost (AUC = {auc_xgb:.4f})')
        
        # Plot diagonal
        ax.plot([0, 1], [0, 1], color=config.COLORS['baseline'], lw=2,
                linestyle='--', label='Random Classifier (AUC = 0.5000)')
        
        ax.set_xlabel('False Positive Rate', fontsize=config.FONT_SIZES['label'])
        ax.set_ylabel('True Positive Rate', fontsize=config.FONT_SIZES['label'])
        ax.set_title('ROC Curve Comparison', fontsize=config.FONT_SIZES['title'], fontweight='bold')
        ax.legend(loc='lower right', fontsize=config.FONT_SIZES['legend'])
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=config.FIGURE_DPI, bbox_inches='tight')
            print(f"✓ ROC curve saved to: {save_path}")
        
        return fig
    
    def plot_precision_recall_comparison(self, lr_results, xgb_results, save_path=None):
        """
        Plot Precision-Recall curves for both models.
        
        Parameters:
        -----------
        lr_results : dict
            Logistic regression results
        xgb_results : dict
            XGBoost results
        save_path : str or Path, optional
            Path to save the figure
        """
        fig, ax = plt.subplots(figsize=config.FIGURE_SIZE_STANDARD)
        
        # Plot Logistic Regression
        precision_lr = lr_results['pr_curve']['precision']
        recall_lr = lr_results['pr_curve']['recall']
        ap_lr = lr_results['average_precision']
        
        ax.plot(recall_lr, precision_lr, color=config.COLORS['lr'], lw=2,
                label=f'Logistic Regression (AP = {ap_lr:.4f})')
        
        # Plot XGBoost
        precision_xgb = xgb_results['pr_curve']['precision']
        recall_xgb = xgb_results['pr_curve']['recall']
        ap_xgb = xgb_results['average_precision']
        
        ax.plot(recall_xgb, precision_xgb, color=config.COLORS['xgb'], lw=2,
                label=f'XGBoost (AP = {ap_xgb:.4f})')
        
        # Plot baseline (assuming 50% prevalence)
        ax.axhline(y=0.5, color=config.COLORS['baseline'], lw=2,
                   linestyle='--', label='Baseline (AP = 0.5000)')
        
        ax.set_xlabel('Recall', fontsize=config.FONT_SIZES['label'])
        ax.set_ylabel('Precision', fontsize=config.FONT_SIZES['label'])
        ax.set_title('Precision-Recall Curve Comparison', 
                    fontsize=config.FONT_SIZES['title'], fontweight='bold')
        ax.legend(loc='best', fontsize=config.FONT_SIZES['legend'])
        ax.grid(True, alpha=0.3)
        ax.set_xlim([0.0, 1.0])
        ax.set_ylim([0.0, 1.05])
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=config.FIGURE_DPI, bbox_inches='tight')
            print(f"✓ PR curve saved to: {save_path}")
        
        return fig
    
    def plot_confusion_matrices(self, lr_results, xgb_results, save_path=None):
        """
        Plot confusion matrices side by side for both models.
        
        Parameters:
        -----------
        lr_results : dict
            Logistic regression results
        xgb_results : dict
            XGBoost results
        save_path : str or Path, optional
            Path to save the figure
        """
        fig, axes = plt.subplots(1, 2, figsize=config.FIGURE_SIZE_WIDE)
        
        # Logistic Regression
        cm_lr = np.array(lr_results['confusion_matrix'])
        disp_lr = ConfusionMatrixDisplay(confusion_matrix=cm_lr,
                                         display_labels=['No CVD', 'CVD'])
        disp_lr.plot(ax=axes[0], cmap='Blues', colorbar=False)
        axes[0].set_title('Logistic Regression', fontsize=config.FONT_SIZES['title'], fontweight='bold')
        
        # XGBoost
        cm_xgb = np.array(xgb_results['confusion_matrix'])
        disp_xgb = ConfusionMatrixDisplay(confusion_matrix=cm_xgb,
                                          display_labels=['No CVD', 'CVD'])
        disp_xgb.plot(ax=axes[1], cmap='Oranges', colorbar=False)
        axes[1].set_title('XGBoost', fontsize=config.FONT_SIZES['title'], fontweight='bold')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=config.FIGURE_DPI, bbox_inches='tight')
            print(f"✓ Confusion matrices saved to: {save_path}")
        
        return fig
    
    def plot_feature_importance_comparison(self, lr_results, xgb_results, top_n=10, save_path=None):
        """
        Plot feature importance comparison for both models.
        
        Parameters:
        -----------
        lr_results : dict
            Logistic regression results with feature importance
        xgb_results : dict
            XGBoost results with feature importance
        top_n : int
            Number of top features to show
        save_path : str or Path, optional
            Path to save the figure
        """
        fig, axes = plt.subplots(1, 2, figsize=(14, 6))
        
        # Logistic Regression - coefficients
        if 'feature_importance' in lr_results:
            features_lr = lr_results['feature_importance']['features'][:top_n]
            coefs_lr = np.abs(lr_results['feature_importance']['coefficients'][:top_n])
            
            y_pos = np.arange(len(features_lr))
            axes[0].barh(y_pos, coefs_lr, color=config.COLORS['lr'])
            axes[0].set_yticks(y_pos)
            axes[0].set_yticklabels(features_lr)
            axes[0].invert_yaxis()
            axes[0].set_xlabel('Absolute Coefficient', fontsize=config.FONT_SIZES['label'])
            axes[0].set_title('Logistic Regression\nTop Features', 
                            fontsize=config.FONT_SIZES['title'], fontweight='bold')
            axes[0].grid(True, alpha=0.3, axis='x')
        
        # XGBoost - gain
        if 'feature_importance' in xgb_results:
            features_xgb = xgb_results['feature_importance']['features'][:top_n]
            gain_xgb = xgb_results['feature_importance']['gain'][:top_n]
            
            y_pos = np.arange(len(features_xgb))
            axes[1].barh(y_pos, gain_xgb, color=config.COLORS['xgb'])
            axes[1].set_yticks(y_pos)
            axes[1].set_yticklabels(features_xgb)
            axes[1].invert_yaxis()
            axes[1].set_xlabel('Gain', fontsize=config.FONT_SIZES['label'])
            axes[1].set_title('XGBoost\nTop Features', 
                            fontsize=config.FONT_SIZES['title'], fontweight='bold')
            axes[1].grid(True, alpha=0.3, axis='x')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=config.FIGURE_DPI, bbox_inches='tight')
            print(f"✓ Feature importance comparison saved to: {save_path}")
        
        return fig
    
    def plot_metrics_comparison(self, lr_results, xgb_results, save_path=None):
        """
        Plot bar chart comparing key metrics between models.
        
        Parameters:
        -----------
        lr_results : dict
            Logistic regression results
        xgb_results : dict
            XGBoost results
        save_path : str or Path, optional
            Path to save the figure
        """
        metrics = ['accuracy', 'precision', 'recall', 'f1', 'roc_auc']
        lr_scores = [lr_results[m] for m in metrics]
        xgb_scores = [xgb_results[m] for m in metrics]
        
        x = np.arange(len(metrics))
        width = 0.35
        
        fig, ax = plt.subplots(figsize=config.FIGURE_SIZE_STANDARD)
        
        bars1 = ax.bar(x - width/2, lr_scores, width, label='Logistic Regression',
                      color=config.COLORS['lr'])
        bars2 = ax.bar(x + width/2, xgb_scores, width, label='XGBoost',
                      color=config.COLORS['xgb'])
        
        # Add value labels on bars
        for bars in [bars1, bars2]:
            for bar in bars:
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width()/2., height,
                       f'{height:.3f}',
                       ha='center', va='bottom', fontsize=9)
        
        ax.set_ylabel('Score', fontsize=config.FONT_SIZES['label'])
        ax.set_title('Model Performance Comparison', 
                    fontsize=config.FONT_SIZES['title'], fontweight='bold')
        ax.set_xticks(x)
        ax.set_xticklabels([m.replace('_', ' ').title() for m in metrics])
        ax.legend(fontsize=config.FONT_SIZES['legend'])
        ax.set_ylim([0, 1.0])
        ax.grid(True, alpha=0.3, axis='y')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=config.FIGURE_DPI, bbox_inches='tight')
            print(f"✓ Metrics comparison saved to: {save_path}")
        
        return fig
    
    def create_comparison_table(self, lr_results, xgb_results):
        """
        Create a formatted comparison table of model metrics.
        
        Parameters:
        -----------
        lr_results : dict
            Logistic regression results
        xgb_results : dict
            XGBoost results
            
        Returns:
        --------
        pd.DataFrame
            Comparison table
        """
        metrics = {
            'Metric': ['Accuracy', 'Precision', 'Recall', 'F1-Score', 'AUC-ROC', 'Avg Precision'],
            'Logistic Regression': [
                f"{lr_results['accuracy']:.4f}",
                f"{lr_results['precision']:.4f}",
                f"{lr_results['recall']:.4f}",
                f"{lr_results['f1']:.4f}",
                f"{lr_results['roc_auc']:.4f}",
                f"{lr_results['average_precision']:.4f}"
            ],
            'XGBoost': [
                f"{xgb_results['accuracy']:.4f}",
                f"{xgb_results['precision']:.4f}",
                f"{xgb_results['recall']:.4f}",
                f"{xgb_results['f1']:.4f}",
                f"{xgb_results['roc_auc']:.4f}",
                f"{xgb_results['average_precision']:.4f}"
            ]
        }
        
        df = pd.DataFrame(metrics)
        
        # Calculate improvement
        improvements = []
        for i in range(len(df)):
            lr_val = float(df.loc[i, 'Logistic Regression'])
            xgb_val = float(df.loc[i, 'XGBoost'])
            improvement = xgb_val - lr_val
            improvements.append(f"{improvement:+.4f}")
        
        df['Improvement'] = improvements
        
        return df
    
    def generate_all_visualizations(self, lr_results, xgb_results, output_dir=None):
        """
        Generate all visualizations and save them.
        
        Parameters:
        -----------
        lr_results : dict
            Logistic regression results
        xgb_results : dict
            XGBoost results
        output_dir : str or Path, optional
            Directory to save figures. If None, uses config.FIGURES_DIR
        """
        if output_dir is None:
            output_dir = config.FIGURES_DIR
        
        config.print_section_header("GENERATING VISUALIZATIONS")
        
        # ROC Curve
        self.plot_roc_comparison(
            lr_results, xgb_results,
            save_path=output_dir / 'roc_curve_comparison.png'
        )
        plt.close()
        
        # Precision-Recall Curve
        self.plot_precision_recall_comparison(
            lr_results, xgb_results,
            save_path=output_dir / 'pr_curve_comparison.png'
        )
        plt.close()
        
        # Confusion Matrices
        self.plot_confusion_matrices(
            lr_results, xgb_results,
            save_path=output_dir / 'confusion_matrices.png'
        )
        plt.close()
        
        # Feature Importance
        self.plot_feature_importance_comparison(
            lr_results, xgb_results,
            save_path=output_dir / 'feature_importance_comparison.png'
        )
        plt.close()
        
        # Metrics Comparison
        self.plot_metrics_comparison(
            lr_results, xgb_results,
            save_path=output_dir / 'metrics_comparison.png'
        )
        plt.close()
        
        # Comparison Table
        comparison_table = self.create_comparison_table(lr_results, xgb_results)
        comparison_table.to_csv(output_dir / 'metrics_comparison_table.csv', index=False)
        print(f"✓ Metrics comparison table saved to: {output_dir / 'metrics_comparison_table.csv'}")
        
        # Print table
        print("\nModel Comparison Table:")
        print(comparison_table.to_string(index=False))
        
        config.print_section_header("ALL VISUALIZATIONS COMPLETE")
        print(f"\nAll figures saved to: {output_dir}")


def load_and_visualize():
    """
    Load saved results and generate all visualizations.
    """
    print("Loading saved results...")
    
    # Load results
    with open(config.LR_RESULTS_FILE, 'r') as f:
        lr_results = json.load(f)
    
    with open(config.XGB_RESULTS_FILE, 'r') as f:
        xgb_results = json.load(f)
    
    print("✓ Results loaded")
    
    # Create visualizations
    visualizer = ModelVisualizer()
    visualizer.generate_all_visualizations(lr_results, xgb_results)
